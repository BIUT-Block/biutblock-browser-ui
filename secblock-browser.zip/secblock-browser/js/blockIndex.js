$(function() {
  blockIndexTable ()
})

// 区块链table
function blockIndexTable () {

  // 接口请求的总条数
  $("#total").html("2")
}